<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

$vendorFilter = $_GET['vendor'] ?? '';
$sort = $_GET['sort'] ?? '';
$search = $_GET['search'] ?? '';

$query = "SELECT p.*, v.vendorName as vendor FROM products p JOIN vendors v ON p.vendorID = v.vendorID WHERE 1=1";
$params = [];
$types = '';


if ($vendorFilter) {
    $query .= " AND v.vendorID = ?";
    $params[] = $vendorFilter;
    $types .= 'i';
}

if ($search) {
    $query .= " AND p.productName LIKE ?";
    $params[] = '%' . $search . '%';
    $types .= 's';
}

if ($sort == 'price_asc') {
    $query .= " ORDER BY p.productPrice ASC";
} elseif ($sort == 'price_desc') {
    $query .= " ORDER BY p.price DESC";
} else {
    $query .= " ORDER BY p.created_at DESC";
}

$stmt = $conn->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();


$vendors = $conn->query("SELECT vendorID, vendorName FROM vendors");

include 'includes/header.php';
?>

<h2 class="catalog-title">Product Catalog</h2>
<p class="catalog-subtitle">Browse, filter and sort furniture</p>

<form method="get" action="" class="mb-2">
    <div class="filter-container">
        <div class="filter-left">
            <div class="form-section-inline">
                <label for="vendor">Vendor</label>
                <select id="vendor" name="vendor">
                    <option value="">All Vendors</option>
                    <?php while ($vendor = $vendors->fetch_assoc()): ?>
                        <option value="<?php echo $vendor['vendorID']; ?>" <?php if ($vendorFilter == $vendor['vendorID']) echo 'selected'; ?>><?php echo $vendor['vendorName']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-section-inline">
                <label for="sort">Sort by</label>
                <select id="sort" name="sort">
                    <option value="">Default</option>
                    <option value="price_asc" <?php if ($sort == 'price_asc') echo 'selected'; ?>>Price Low to High</option>
                    <option value="price_desc" <?php if ($sort == 'price_desc') echo 'selected'; ?>>Price High to Low</option>
                </select>
            </div>
        </div>
        <div class="filter-right">
            <div class="form-section-inline">
                <label for="search">Search</label>
                <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Product name">
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </div>
</form>

<div class="grid">
    <?php while ($product = $result->fetch_assoc()): ?>
        <div class="product-card">
            <img src="images/products/<?php echo $product['image']; ?>" alt="<?php echo $product['productName']; ?>">
            <div class="content">
                <h3><?php echo $product['productName']; ?></h3>
                <p><?php echo substr($product['description'], 0, 100) . '...'; ?></p>
                <p><?php echo formatPrice($product['productPrice']); ?></p>
                <p><?php echo $product['vendor']; ?></p>
                <a href="detail.php?id=<?php echo $product['productID']; ?>" class="btn btn-primary">View Detail</a>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php
$stmt->close();
include 'includes/footer.php';
?>