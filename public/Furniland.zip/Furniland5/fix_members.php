<?php
include 'includes/db_connect.php';

function fixPassword($email, $newPassword, $conn) {
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->bind_param("ss", $hash, $email);

    if ($stmt->execute()) {
        echo "UPDATED: $email → $newPassword<br>";
    } else {
        echo "ERROR: " . $stmt->error . "<br>";
    }

    $stmt->close();
}

fixPassword("alicia@gmail.com", "alicia123", $conn);
fixPassword("brandon@gmail.com", "brandon123", $conn);

echo "<br>DONE!";
?>
