<?php
session_start();
include "includes/db_connect.php";
include "includes/functions.php";

$query =
    "SELECT p.productID, 
    p.productName, 
    p.productPrice, 
    p.image, 
    p.description, 
    v.vendorName as vendor FROM products p JOIN vendors v ON p.vendorID = v.vendorID ORDER BY p.productID ASC LIMIT 6";

$result = $conn->query($query);
if (!$result) {
    die(
        "Database not set up. Please run sql/furniland.sql to create tables and insert sample data."
    );
}

include "includes/header.php";
?>

<h2 class="furniland-bold">Furniland</h2>
<p class="furniland-tagline">Furnitures you might love</p>

<div class="grid">
    <?php while ($product = $result->fetch_assoc()): ?>
        <div class="product-card">
            <img src="images/products/<?php echo $product[
                "image"
            ]; 
            ?>" alt="<?php echo $product["productName"]; ?>">
            <div class="content">
                <h3><?php echo $product["productName"]; ?></h3>
                <p><?php echo substr($product['description'], 0, 100) . '...'; ?></p>
                <p><?php echo formatPrice($product["productPrice"]); ?></p>
                <a href="detail.php?id=<?php echo $product[
                    "productID"
                ]; ?>" class="btn btn-primary">View Detail</a>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php include "includes/footer.php"; ?>
