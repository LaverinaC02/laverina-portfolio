<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$userID = $_SESSION['userID'];

if (isset($_POST['update_qty'])) {
    $cartID = $_POST['cartID'];
    $quantity = (int)$_POST['quantity'];
    if ($quantity > 0) {
        $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE cartID = ? AND userID = ?");
        $stmt->bind_param("iii", $quantity, $cartID, $userID);
        $stmt->execute();
        $stmt->close();
    } else 
    
    {   $stmt = $conn->prepare("DELETE FROM cart WHERE cartID = ? AND userID = ?");
        $stmt->bind_param("ii", $cartID, $userID);
        $stmt->execute();
        $stmt->close();
    }
    redirect('cart.php');
}

if (isset($_GET['delete'])) {
    $cartID = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE cartID = ? AND userID = ?");
    $stmt->bind_param("ii", $cartID, $userID);
    $stmt->execute();
    $stmt->close();
    redirect('cart.php');
}

if (isset($_POST['checkout'])) {
    $query = "SELECT SUM(p.productPrice * c.quantity) as total FROM cart c JOIN products p ON c.productID = p.productID WHERE c.userID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $total = $result->fetch_assoc()['total'] ?? 0;
    $stmt->close();

    if ($total > 0) {
        $stmt = $conn->prepare("INSERT INTO transactions (userID, totalTransaction, transactionDate) VALUES (?, ?, NOW())");
        $stmt->bind_param("id", $userID, $total);
        $stmt->execute();
        $transactionID = $conn->insert_id;
        $stmt->close();

        $query = "INSERT INTO transaction_details (transactionID, productID, subtotal, quantity) SELECT ?, c.productID, p.productPrice, c.quantity FROM cart c JOIN products p ON c.productID = p.productID WHERE c.userID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $transactionID, $userID);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM cart WHERE userID = ?");
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $stmt->close();

        redirect('history.php');
    }
}

$query = "SELECT c.cartID, 
p.productID, 
p.productName, 
p.productPrice, 
p.image, 
c.quantity, (p.productPrice * c.quantity) as subtotal FROM cart c JOIN products p ON c.productID = p.productID WHERE c.userID = ? ORDER BY c.cartID";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();

$total = 0;
$cartItems = [];
while ($row = $result->fetch_assoc()) {
    $cartItems[] = $row;
    $total += $row['subtotal'];
}
$stmt->close();

include 'includes/header.php';
?>

<div class="title-container">
    <h4 class="title-cart">Your Cart</h4>
</div>

<?php if (empty($cartItems)): ?>
    <p class="txt-center" style="font-style: italic;">Your cart is empty</p>
<?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cartItems as $item): ?>
                <tr>
                    <td><img src="images/products/<?php echo $item['image']; ?>" alt="<?php echo $item['productName']; ?>" class="front-img"></td>
                    <td><?php echo $item['productName']; ?></td>
                    <td><?php echo formatPrice($item['productPrice']); ?></td>
                     <td>
                         <form method="post" action="" class="inline-form">
                             <input type="hidden" name="cartID" value="<?php echo $item['cartID']; ?>">
                             <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="0" class="qty-input" onchange="this.form.submit()">
                         </form>
                     </td>
                     <td><?php echo formatPrice($item['subtotal']); ?></td>
                      <td><a href="?delete=<?php echo $item['cartID']; ?>" class="text-red" onclick="return confirm('Delete this item?')">Delete</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="txt-right mb-2">
        <h3>Grand Total: <?php echo formatPrice($total); ?></h3>
        <form method="post" action="">
            <button type="submit" name="checkout" class="btn btn-primary">Checkout</button>
        </form>
    </div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
