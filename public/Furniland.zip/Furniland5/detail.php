<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

$productID = $_GET['id'] ?? 0;
$query = "SELECT p.*, v.vendorName as vendor, v.location FROM products p JOIN vendors v ON p.vendorID = v.vendorID WHERE p.productID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $productID);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    redirect('catalog.php');
}
$product = $result->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    if (!isLoggedIn()) {
        redirect('login.php?return=' . urlencode($_SERVER['REQUEST_URI']));
    }
    $quantity = (int)$_POST['quantity'];
    if ($quantity > 0) {
        $userID = $_SESSION['userID'];
        $stmt = $conn->prepare("INSERT INTO cart (userID, productID, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)");
        $stmt->bind_param("iii", $userID, $productID, $quantity);
        $stmt->execute();
        $stmt->close();
        redirect('cart.php');
    }
}

include 'includes/header.php';
?>

<div class="flex">
        <div class="flex-1">
            <img src="images/products/<?php echo $product['image']; ?>" alt="<?php echo $product['productName']; ?>" class="large-img">
        </div>
        <div class="flex-1">
            <h2 class="text-white"><?php echo $product['productName']; ?></h2>
            <p><?php echo $product['description']; ?></p>
            <p class="text-blue"><?php echo formatPrice($product['productPrice']); ?></p>
            <p><strong>Vendor:</strong> <?php echo $product['vendor']; ?></p>
            <p><strong>Locations:</strong> <?php echo $product['location']; ?></p>
            <form method="post" action="">
                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" value="1" min="1" required>
                </div>
                <button type="submit" name="add_to_cart" class="btn btn-primary btn-wider">Add to Cart</button>
            </form>
        </div>
</div>

<?php include 'includes/footer.php'; ?>