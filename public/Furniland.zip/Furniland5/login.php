<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

if (!isLoggedIn() && getRememberMe()) {
    $userID = getRememberMe();
    $stmt = $conn->prepare("SELECT userID, username, role FROM users WHERE userID = ?");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['userID'] = $user['userID'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
    }
    $stmt->close();
}

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $conn->prepare("SELECT userID, username, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                $_SESSION['userID'] = $user['userID'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                if ($remember) {
                    setRememberMe($user['userID']);
                }
                redirect('index.php');
            } else {
                $error = 'Invalid password.';
            }
        } else {
            $error = 'Email not found.';
        }
        $stmt->close();
    }
}

include 'includes/header.php';
?>

<div class="card form-center">
    <h2 class="login-head">Login</h2>
    <?php if ($error): ?>
        <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>
    <form id="loginForm" method="post" action="">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="remember"><input type="checkbox" name="remember" id="remember"> Remember Me</label>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Login</button>
    </form>
    <p class="auth-link">Don't have an account? <a href="register.php">Register here</a></p>
</div>

<script src="js/scripts.js"></script>
<?php include 'includes/footer.php'; ?>