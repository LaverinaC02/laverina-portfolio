CREATE DATABASE IF NOT EXISTS furniland;
USE furniland;

CREATE TABLE users (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    gender ENUM('Male','Female') NOT NULL,
    dob DATE NOT NULL,
    role ENUM('member','admin') DEFAULT 'member',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE vendors (
    vendorID INT AUTO_INCREMENT PRIMARY KEY,
    vendorName VARCHAR(20) NOT NULL,
    location VARCHAR(100) NOT NULL
);

CREATE TABLE products (
    productID INT AUTO_INCREMENT PRIMARY KEY,
    productName VARCHAR(30) NOT NULL,
    description VARCHAR(255) NOT NULL,
    procuctPrice FLOAT(10) NOT NULL,
    image VARCHAR(100) NOT NULL,
    vendorID INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendorID) REFERENCES vendors(vendorID)
);

CREATE TABLE cart (
    cartID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    productID INT NOT NULL,
    quantity INT(5) NOT NULL,
    FOREIGN KEY (userID) REFERENCES users(userID),
    FOREIGN KEY (productID) REFERENCES products(productID),
    UNIQUE KEY unique_cart (userID, productID)
);

CREATE TABLE transactions (
    transactionID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT NOT NULL,
    totalTransaction FLOAT(10) NOT NULL,
    transactionDate DATE NOT NULL,
    FOREIGN KEY (userID) REFERENCES users(userID)
);

CREATE TABLE transaction_details (
    detailID INT AUTO_INCREMENT PRIMARY KEY,
    transactionID INT NOT NULL,
    productID INT NOT NULL,
    quantity INT(5) NOT NULL,
    subtotal INT(10) NOT NULL,
    FOREIGN KEY (transactionID) REFERENCES transactions(transactionID),
    FOREIGN KEY (productID) REFERENCES products(productID)
);


INSERT INTO users (username, email, password, gender, dob, role) VALUES
('LS015', 'admin@furniland.com', 
'$2y$10$yidhm6NRZN4k3Kf.k9Aa0OhRuKJ3j10osnXYm0oD6rGelWclLciBa', 
'Male', '2000-01-01', 'admin'),

('Alicia', 'alicia@gmail.com', 
'$2y$10$MLTImWamf4BZOA0rx1Z3Ru7W.UMa7gI4fAwWwQ0V5VKxD0t3NqbRO', 
'Female', '2001-03-21', 'member'),

('Brandon', 'brandon@gmail.com',
'$2y$10$VrVfqzvW9v.3v4UUdUd5RevlAfmugXE7tgo/9lXtTGnxcB1A390tO',
'Male', '2000-07-10', 'member');


INSERT INTO vendors (vendorName, location) VALUES
('Magnusson', 'Jakarta'),
('Lumber2Love', 'Lombok'),
('Decorilla', 'Surabaya'),
('Lazzoni', 'Tangerang'),
('Mollino', 'Solo');

INSERT INTO products (productName, description, productPrice, image, vendorID) VALUES
('Othello Mirror', 'Circular decorative wooden mirror.', 2000000, 'cermin.png', 3),
('Astra Bookshelf', 'Minimalist wall shelf with roomy storage.', 3000000, 'rakbuku.png', 5),
('Luxe Sofa', 'Premium 3-seater leather sofa.', 5500000, 'sofa.png', 1),
('Modular Desk', 'Modern curved desk with storage units.', 2400000, 'meja.png', 4),
('Cocoon Chair', 'Curved lounge chair with soft cushions.', 1700000, 'armchair.png', 2),
('Oak Dining Set', 'Solid wood dining table with 5 chairs.', 4200000, 'mejaset.png', 5),
('Urban Lamp', 'Classic lamp with cone shade.', 1500000, 'lampu.png', 1),
('Wooden Wardrobe', 'Modern wardrobe with premium sliding wooden doors.', 3200000, 'lemari.png', 4),
('Elegant Bed Frame', 'King size bed frame in oak wood.', 4600000, 'kasur.png', 3),
('Compact Nightstand', 'Minimalist nightstand with a drawer.', 900000, 'nightstand.png', 2),
('Vintage Chair', 'Comfortable cushioned armchair.', 1300000, 'chair.png', 3),
('Wood Coffee Table', 'Solid wood coffee table with unique legs.', 2300000, 'coffeetable.png', 1);

INSERT INTO transactions (transactionID, userID, totalPrice) VALUES
(1, 2, 9000000),
(2, 3, 2600000);


INSERT INTO transaction_details (transactionID, productID, subtotal, quantity) VALUES
(1, 3, 5500000, 1),
(1, 7, 1500000, 1),
(1, 1, 2000000, 1),
(2, 5, 1700000, 1),
(2, 10, 900000, 1);
