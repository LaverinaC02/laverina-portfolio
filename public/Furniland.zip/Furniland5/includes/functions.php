<?php
function redirect($url) {
    header("Location: $url");
    exit();
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'admin';
}

function isLoggedIn() {
    return isset($_SESSION['userID']);
}

function formatPrice($productPrice) {
    return 'Rp ' . number_format($productPrice, 0, ',', '.');
}

function setRememberMe($userID) {
    setcookie('user_id', $userID, time() + 604800, "/");
}

function getRememberMe() {
    return isset($_COOKIE['user_id']) ? $_COOKIE['user_id'] : null;
}

function clearRememberMe() {
    setcookie('user_id', '', time() - 3600, "/");
}
?>