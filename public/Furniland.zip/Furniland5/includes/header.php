<?php
$base = "/Furniland5";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Furniland</title>
    <link rel="stylesheet" href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false) ? '../css/style.css' : 'css/style.css'; ?>">
</head>
<body>
    <header>
        <nav>
            <div class="nav-wrap">
                <div class="nav-section-left">
                    <h1>Furniland</h1>
                    <?php if (isLoggedIn() && isAdmin()): ?>
                    <a href="/Furniland5/dashboard.php">Dashboard</a>
                <?php else: ?>
                    <a href="/Furniland5/index.php">Home</a>
                    <a href="/Furniland5/catalog.php">Catalog</a>
                <?php endif; ?>

                </div>
                <div class="nav--section-right">
                    <?php if (isLoggedIn()): ?>
                        <?php if (isAdmin()): ?>
                            <a href="<?php echo $base; ?>/profile.php" class="nav-hello">
                                Hello, <?php echo $_SESSION['username']; ?>
                            </a>
                            <a href="<?php echo $base; ?>/logout.php">Logout</a>
                        <?php else: ?>

                
                            <a href="<?php echo $base; ?>/profile.php" class="nav-hello">
                                Hello, <?php echo $_SESSION['username']; ?>
                            </a>
                            <a href="<?php echo $base; ?>/cart.php">Cart</a>
                            <a href="<?php echo $base; ?>/history.php">History</a>
                            <a href="<?php echo $base; ?>/logout.php">Logout</a>
                            <?php endif; ?>

                    <?php else: ?>
                            <a href="<?php echo $base; ?>/login.php">Login</a>
                            <a href="<?php echo $base; ?>/register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>
    <main>