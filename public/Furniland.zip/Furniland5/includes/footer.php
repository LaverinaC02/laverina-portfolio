</main>
    <footer>
        <p>&copy; 2025 Furniland. All rights reserved.</p>
        <p>Contact us at <span class="footer-email">furniland.support@gmail.com</span></p>
    </footer>

</body>
</html>