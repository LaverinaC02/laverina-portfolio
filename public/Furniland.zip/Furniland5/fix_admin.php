<?php
include 'includes/db_connect.php';

if (!$conn) {
    die("KONEKSI ERROR: " . mysqli_connect_error());
}

$email = "admin@furniland.com";
$newHash = password_hash("admin123", PASSWORD_DEFAULT);
se {
    echo "SQL ERROR:<br>" . $conn->error;
}
