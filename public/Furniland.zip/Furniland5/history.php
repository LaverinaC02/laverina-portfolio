<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$userID = $_SESSION['userID'];

$query = "SELECT * FROM transactions WHERE userID = ? ORDER BY transactionDate DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userID);
$stmt->execute();
$transactions = $stmt->get_result();
$stmt->close();

include 'includes/header.php';
?>

<h2 class="page-heading">Transaction History</h2>

<?php if ($transactions->num_rows == 0): ?>
    <p class="txt-center" style="font-style: italic;">You haven't made any transactions yet</p>
<?php else: ?>
    <?php while ($trans = $transactions->fetch_assoc()): ?>
        <div class="card">
            <div onclick="toggleAccordion(<?php echo $trans['transactionID']; ?>)" class="accordion-head flex-between">
            <div class="flex-between" 
            style="display:flex; justify-content:space-between; align-items:center; width:100%">

            <div>
                <strong>Transaction ID: <?php echo $trans['transactionID']; ?></strong>
            <?php
            $date = $trans['transactionDate'];
            $formattedDate = ($date && strtotime($date) > 0)
                ? date('d M Y', strtotime($date))
                : "Invalid Date";
            ?>
            <p>Date: <?php echo $formattedDate; ?></p>
            </div>

    
            <div class="total-display">
                Total: <?php echo formatPrice($trans['totalTransaction']); ?>
            </div>

        </div>


            </div>
            <div id="accordion_<?php echo $trans['transactionID']; ?>" class="accordion-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT td.*, p.productName FROM transaction_details td JOIN products p ON td.productID = p.productID WHERE td.transactionID = ?";
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("i", $trans['transactionID']);
                        $stmt->execute();
                        $details = $stmt->get_result();
                        while ($detail = $details->fetch_assoc()):
                        ?>
                            <tr>
                                <td><?php echo $detail['productName']; ?></td>
                                <td><?php echo formatPrice($detail['subtotal']); ?></td>
                                <td><?php echo $detail['quantity']; ?></td>
                                <td><?php echo formatPrice($detail['subtotal'] * $detail['quantity']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endwhile; ?>
<?php endif; ?>

<script src="js/scripts.js"></script>
<?php include 'includes/footer.php'; ?>