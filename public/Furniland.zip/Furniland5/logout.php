<?php
session_start();
include 'includes/functions.php';

session_destroy();
clearRememberMe();
redirect('index.php');
?>