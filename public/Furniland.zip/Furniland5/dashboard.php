<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

if (!isAdmin()) {
    redirect('index.php');
}

include 'includes/header.php';
?>

<h2 class="dashboard-title">Admin Dashboard</h2>

    <div class="grid-manage">
        <a href="admin/manage_products.php" class="header-link">
            <div class="card db-card">
                <h3>Manage Products</h3>
                <p>View, edit, and add furnitures products.</p>
            </div>
        </a>
        <a href="admin/manage_vendors.php" class="header-link">
            <div class="card db-card">
                <h3>Manage Vendors</h3>
                <p>View and manage furnitures vendors.</p>
            </div>
        </a>
        <a href="admin/manage_users.php" class="header-link">
            <div class="card db-card">
                <h3>Manage Users</h3>
                <p>View and control user accounts.</p>
            </div>
        </a>
        <a href="admin/transactions.php" class="header-link">
            <div class="card db-card">
                <h3>View Transactions</h3>
                <p>Monitor purchase history and details.</p>
            </div>
        </a>
    </div>


    <div class="welcome-admin-container">
        <div class="card welcome-admin">
            <h3>Welcome, <?php echo $_SESSION['username']; ?>!</h3>
            <p>Use the card above to manage the platform. Keep track of users, inventory, vendors, and transactions efficiently.</p>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>