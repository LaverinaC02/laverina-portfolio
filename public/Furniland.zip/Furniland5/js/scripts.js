function validateRegister() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const dob = document.getElementById('dob').value;

    if (!email.includes('@')) {
        alert('Email must be valid');
        return false;
    }
    if (password.length < 8) {
        alert('Password must be at least 8 characters');
        return false;
    }
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return false;
    }
    const today = new Date();
    const birthDate = new Date(dob);
    if (birthDate >= today) {
        alert('Date of birth must be in the past');
        return false;
    }
    return true;
}

function validateLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!email || !password) {
        alert('Please fill in all fields');
        return false;
    }
    return true;
}


function updateQty(cartID, newQty) {
    if (newQty < 1) return;
    document.getElementById('qty_' + cartID).value = newQty;
    document.getElementById('form_' + cartID).submit();
}

function toggleAccordion(id) {
    const content = document.getElementById('accordion_' + id);
    content.style.display = content.style.display === 'block' ? 'none' : 'block';
}

let lastScrollTop = 0;
window.addEventListener('scroll', function() {
    const nav = document.querySelector('header');
    let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > lastScrollTop) {
        if (nav) nav.style.top = '-100px';
    } else {
        if (nav) nav.style.top = '0';
    }
    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});

document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            if (!validateRegister()) {
                e.preventDefault();
            }
        });
    }

    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            if (!validateLogin()) {
                e.preventDefault();
            }
        });
    }

});