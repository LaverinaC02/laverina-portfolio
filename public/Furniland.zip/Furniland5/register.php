<?php
session_start();
include 'includes/db_connect.php';
include 'includes/functions.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    error_log("Registration POST received: " . json_encode($_POST));
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($gender) || empty($dob)) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Email must be a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (!in_array($gender, ['Male', 'Female'])) {
        $error = 'Invalid gender.';
    } elseif (strtotime($dob) >= time()) {
        $error = 'Date of birth must be in the past.';
    } else {
        $stmt = $conn->prepare("SELECT userID FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $error = 'Username or email already exists.';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, gender, dob) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $username, $email, $hashed_password, $gender, $dob);
            if ($stmt->execute()) {
                redirect('login.php');
            } else {
                error_log("Registration insert failed: " . $stmt->error);
                $error = 'Registration failed. Please try again. Error: ' . $stmt->error;
            }
        }
        $stmt->close();
    }
}

include 'includes/header.php';
?>

<div class="card form-center">
    <h2 class="login-head">Register</h2>
    <?php if ($error): ?>
        <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>
    <form id="registerForm" method="post" action="">
        <div class="form-section">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-section">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-section">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-section">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
        <div class="form-section">
            <label>Gender</label>
            <div class="radio-group">
                <label><input type="radio" name="gender" value="Male" required> Male</label>
                <label><input type="radio" name="gender" value="Female" required> Female</label>
            </div>
        </div>
        <div class="form-section">
            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" required>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Register</button>
    </form>
    <p class="auth-link">Already have an account? <a href="login.php">Login here</a></p>
</div>

<script src="js/scripts.js"></script>
<?php include 'includes/footer.php'; ?>