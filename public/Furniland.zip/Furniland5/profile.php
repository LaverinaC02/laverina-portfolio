<?php
session_start();
include "includes/db_connect.php";
include "includes/functions.php";

if (!isLoggedIn()) {
    redirect("login.php");
}

$userID = $_SESSION["userID"];
$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["update_info"])) {
        $username = trim($_POST["username"]);
        $email = trim($_POST["email"]);
        $gender = $_POST["gender"];
        $dob = $_POST["dob"];

        if (
            empty($username) ||
            empty($email) ||
            empty($gender) ||
            empty($dob)
        ) {
            $error = "Please fill in all fields.";
        } elseif (
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            !str_ends_with($email, "@gmail.com")
        ) {
            $error = "Email must be a valid @gmail.com address.";
        } elseif (!in_array($gender, ["Male", "Female"])) {
            $error = "Invalid gender.";
        } elseif (strtotime($dob) >= time()) {
            $error = "Date of birth must be in the past.";
        } else {
            $stmt = $conn->prepare(
                "SELECT userID FROM users WHERE (username = ? OR email = ?) AND userID != ?",
            );
            $stmt->bind_param("ssi", $username, $email, $userID);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $error = "Username or email already taken.";
            } else {
                $stmt = $conn->prepare(
                    "UPDATE users SET username = ?, email = ?, gender = ?, dob = ? WHERE userID = ?",
                );
                $stmt->bind_param(
                    "ssssi",
                    $username,
                    $email,
                    $gender,
                    $dob,
                    $userID,
                );
                if ($stmt->execute()) {
                    $_SESSION["username"] = $username;
                    $success = "Profile updated successfully.";
                } else {
                    $error = "Update failed.";
                }
                $stmt->close();
            }
        }
    } elseif (isset($_POST["change_password"])) {
        $old_password = $_POST["old_password"];
        $new_password = $_POST["new_password"];
        $confirm_password = $_POST["confirm_password"];

        if (
            empty($old_password) ||
            empty($new_password) ||
            empty($confirm_password)
        ) {
            $error = "Please fill in all fields.";
        } 
        
        elseif (strlen($new_password) < 8) {
            $error = "New password must be at least 8 characters.";
        } 
        
        elseif ($new_password !== $confirm_password) {
            $error = "New passwords do not match.";
        } 
        
        else {
            $stmt = $conn->prepare(
                "SELECT password FROM users WHERE userID = ?",
            );
            $stmt->bind_param("i", $userID);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            if (!password_verify($old_password, $user["password"])) {
                $error = "Old password is incorrect.";
            } 
            else {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare(
                    "UPDATE users SET password = ? WHERE userID = ?",
                );
                $stmt->bind_param("si", $hashed, $userID);
                if ($stmt->execute()) {
                    $success = "Password changed successfully.";
                } else {
                    $error = "Password change failed.";
                }
            }
            $stmt->close();
        }
    } 
    elseif (isset($_POST["delete_account"])) {
        $confirm_password = $_POST["confirm_delete"];
        $stmt = $conn->prepare("SELECT password FROM users WHERE userID = ?");
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $user_pass = $result->fetch_assoc();
        if (!password_verify($confirm_password, $user_pass["password"])) {
            $error = "Incorrect password.";
        } 
        
        else {
            $stmt = $conn->prepare("DELETE FROM cart WHERE userID = ?");
            $stmt->bind_param("i", $userID);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM users WHERE userID = ?");
            $stmt->bind_param("i", $userID);
            if ($stmt->execute()) {
                session_destroy();
                clearRememberMe();
                redirect("index.php");
            } else {
                $error = "Account deletion failed.";
            }
            $stmt->close();
        }
    }
}

$stmt = $conn->prepare(
    "SELECT username, email, gender, dob FROM users WHERE userID = ?",
);
$stmt->bind_param("i", $userID);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

include "includes/header.php";
?>

<h2 class="title-cart" style="margin-bottom: 0.5rem;">Your Profile</h2>

<?php if ($error): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>
<?php if ($success): ?>
    <p class="success"><?php echo $success; ?></p>
<?php endif; ?>

<div class="card form-center profile-card-first">
    <h3>Update Profile Information</h3>
    <form method="post" action="">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="<?php echo $user[
                "username"
            ]; 
            ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo $user[
                "email"
            ]; ?>" required>
        </div>
        <div class="form-group">
            <label>Gender</label>
            <label><input type="radio" name="gender" value="Male" <?php if (
                $user["gender"] == "Male"
            ) {
                echo "checked";
            } ?> required> Male</label>
            <label><input type="radio" name="gender" value="Female" <?php if (
                $user["gender"] == "Female"
            ) {
                echo "checked";
            } ?> required> Female</label>
        </div>
        <div class="form-group">
            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" value="<?php echo $user[
                "dob"
            ]; ?>" required>
        </div>
        <button type="submit" name="update_info" class="btn btn-primary btn-full">Update</button>
    </form>
</div>

<div class="card form-center profile-card">
    <h3>Change Password</h3>
    <form method="post" action="">
        <div class="form-group">
            <label for="old_password">Old Password</label>
            <input type="password" id="old_password" name="old_password" required>
        </div>
        <div class="form-group">
            <label for="new_password">New Password</label>
            <input type="password" id="new_password" name="new_password" required>
        </div>
        <div class="form-group">
            <label for="confirm_password">Confirm New Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" name="change_password" class="btn btn-primary btn-full">Change Password</button>
    </form>
</div>

<div class="card form-center delete-card">
    <h3 class="text-red">Delete Account</h3>
    <p class="text-red">Once deleted, your account cannot recovered</p>
    <form method="post" action="" onsubmit="return confirm('Are you sure you want to delete your account?')">
        <div class="form-group">
            <label for="confirm_delete">Confirm Password</label>
            <input type="password" id="confirm_delete" name="confirm_delete" required>
        </div>
        <button type="submit" name="delete_account" class="btn btn-danger btn-full text-white">Delete Account</button>
    </form>
</div>

<?php include "includes/footer.php"; ?>
