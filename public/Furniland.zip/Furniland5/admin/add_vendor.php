<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);

    if (empty($name) || empty($location)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO vendors (vendorName, location) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $location);
        if ($stmt->execute()) {
            redirect('manage_vendors.php');
        } else {
            $error = 'Failed to add vendor.';
        }
        $stmt->close();
    }
}

include '../includes/header.php';
?>

<div class="card add-card">
<h2 class="text-white">Add New Vendor</h2>

<?php if ($error): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
    </div>
    <div class="form-group">
        <label for="location">Location</label>
        <input type="text" id="location" name="location" required>
    </div>
    <button type="submit" class="btn btn-primary btn-full">Add</button>
</form>
</div>

<?php include '../includes/footer.php'; ?>