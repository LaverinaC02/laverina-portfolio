<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (isset($_GET['delete'])) {
    $userID = $_GET['delete'];

    $check = $conn->prepare("SELECT role FROM users WHERE userID = ?");
    $check->bind_param("i", $userID);
    $check->execute();
    $roleResult = $check->get_result()->fetch_assoc();
    $check->close();

    if ($roleResult['role'] === 'admin') {
        redirect('manage_users.php');
    }

    $stmt = $conn->prepare("DELETE FROM transaction_details WHERE transactionID IN 
                            (SELECT transactionID FROM transactions WHERE userID = ?)");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM transactions WHERE userID = ?");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM users WHERE userID = ?");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();

    redirect('manage_users.php');
}


if (!isAdmin()) {
    redirect('../index.php');
}

$query = "SELECT userID, username, email, gender, dob, role FROM users ORDER BY created_at DESC";
$result = $conn->query($query);

include '../includes/header.php';
?>

<div class="admin-content">
<div class="title-container">
    <h4 class="title-left">Manage Users</h4>
</div>

<table class="table">
    <thead>
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Date of Birth</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($user = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $user['username']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td><?php echo $user['gender']; ?></td>
                <td><?php echo $user['dob']; ?></td>
                <td><?php echo $user['role']; ?></td>
                <td>
                    <?php if ($user['role'] == 'admin'): ?>
                        <em>Current Admin</em>
                    <?php else: ?>
                        <a href="?delete=<?php echo $user['userID']; ?>" class="text-red" onclick="return confirm('Delete this user?')">Delete</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php
if (isset($_GET['delete'])) {
    $userID = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE userID = ? AND role != 'admin'");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->close();
    redirect('manage_users.php');
}
?>

</div>

<?php include '../includes/footer.php'; ?>
