<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$query = "SELECT t.*, u.username FROM transactions t JOIN users u ON t.userID = u.userID ORDER BY t.transactionDate DESC";
$result = $conn->query($query);

include '../includes/header.php';
?>

<div class="admin-content">
<div class="title-container">
    <h4 class="title-left">All Transactions</h4>
</div>

<table class="table">
    <thead>
        <tr>
            <th>Transaction ID</th>
            <th>User</th>
            <th>Total Price</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($trans = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $trans['transactionID']; ?></td>
                <td><?php echo $trans['username']; ?></td>
                <td><?php echo formatPrice($trans['totalTransaction']); ?></td>
                <td><?php echo $trans['transactionDate']; ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>
</div>

<script src="../js/scripts.js"></script>
<?php include '../includes/footer.php'; ?>