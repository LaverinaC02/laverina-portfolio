<?php
session_start();
include "../includes/db_connect.php";
include "../includes/functions.php";


if (!isAdmin()) {
    redirect("../index.php");
}

if (isset($_GET["delete"])) {
    $productID = $_GET["delete"];
    $check = $conn->prepare("SELECT 1 FROM transaction_details WHERE productID = ?");
    $check->bind_param("i", $productID);
    $check->execute();
    $checkResult = $check->get_result();

    if ($checkResult->num_rows > 0) {
        echo "<script>
                alert('Cannot delete this product because it is used in past transactions.');
                window.location='manage_products.php';
              </script>";
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM products WHERE productID = ?");
    $stmt->bind_param("i", $productID);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Product deleted successfully.'); window.location='manage_products.php';</script>";
    exit;
}

$vendorFilter = $_GET["vendor"] ?? "";
$query =
    "SELECT p.*, v.vendorName as vendor FROM products p JOIN vendors v ON p.vendorID = v.vendorID";
if ($vendorFilter) {
    $query .= " WHERE p.vendorID = ?";
}
$query .= " ORDER BY p.created_at DESC";

if ($vendorFilter) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $vendorFilter);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

include "../includes/header.php";
?>

<div class="admin-content">
<div class="title-container flex-between">
    <h4 class="title-left">Manage Products</h4>
    <a href="add_product.php" class="btn btn-light btn-sm-custom">+ Add Product</a>
</div>

<div class="filter-container mb-1 filter-left">
    <select id="vendor-filter" onchange="filterProducts(this.value)" class="select-small">
        <option value="">All Vendors</option>
        <?php
        $vendors = $conn->query("SELECT vendorID, vendorName FROM vendors ORDER BY vendorName");
        while ($vendor = $vendors->fetch_assoc()) {
            echo "<option value='{$vendor["vendorID"]}'>{$vendor["vendorName"]}</option>";
        }
        ?>
    </select>
</div>

<table class="table">
    <thead>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Vendor</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($product = $result->fetch_assoc()): ?>
            <tr>
                <td><img src="../images/products/<?php echo $product[
                    "image"
                ]; ?>" alt="" class="front-img"></td>
                <td><?php echo $product["productName"]; ?></td>
                <td><?php echo formatPrice($product["productPrice"]); ?></td>
                <td><?php echo $product["vendor"]; ?></td>
                <td>
                    <a href="edit_product.php?productID=<?php echo $product['productID']; ?>" class="text-blue">Edit</a><br>
                    <a href="?delete=<?php echo $product['productID']; ?>" class="text-red" onclick="return confirm('Delete this product?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>
</div>

<?php include "../includes/footer.php"; ?>
