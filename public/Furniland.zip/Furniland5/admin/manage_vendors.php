<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$query = "SELECT * FROM vendors ORDER BY vendorName";
$result = $conn->query($query);

include '../includes/header.php';
?>

<div class="admin-content">
<div class="title-container flex-between">
    <h4 class="title-left">Manage Vendors</h4>
    <a href="add_vendor.php" class="btn btn-light btn-sm-custom">+ Add Vendor</a>
</div>

<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Location</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($vendor = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $vendor['vendorName']; ?></td>
                <td><?php echo $vendor['location']; ?></td>
                <td>
                    <a href="edit_vendor.php?vendorID=<?php echo $vendor['vendorID']; ?>" class="text-blue">Edit</a><br>
                    <a href="?delete=<?php echo $vendor['vendorID']; ?>" class="text-red" onclick="return confirm('Delete this vendor?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php
if (isset($_GET['delete'])) {
    $vendorID = $_GET['delete'];
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products WHERE vendorID = ?");
    $stmt->bind_param("i", $vendorID);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $result->fetch_assoc()['count'];
    $stmt->close();
    if ($count > 0) {
        echo "<script>alert('Cannot delete vendor with products.');</script>";
    } else {
        $stmt = $conn->prepare("DELETE FROM vendors WHERE vendorID = ?");
        $stmt->bind_param("i", $vendorID);
        $stmt->execute();
        $stmt->close();
    }
    redirect('manage_vendors.php');
}
?>

</div>

<?php include '../includes/footer.php'; ?>
