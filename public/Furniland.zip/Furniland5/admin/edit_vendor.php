<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$vendorID = $_GET['vendorID'] ?? 0;
if (!$vendorID) {
    redirect('manage_vendors.php');
}

$query = "SELECT * FROM vendors WHERE vendorID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $vendorID);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    redirect('manage_vendors.php');
}
$vendor = $result->fetch_assoc();
$stmt->close();

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);

    if (empty($name) || empty($location)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $conn->prepare("UPDATE vendors SET vendorName = ?, location = ? WHERE vendorID = ?");
        $stmt->bind_param("ssi", $name, $location, $vendorID);
        if ($stmt->execute()) {
            redirect('manage_vendors.php');
        } else {
            $error = 'Failed to update vendor.';
        }
        $stmt->close();
    }
}

include '../includes/header.php';
?>

<h2>Edit Vendor</h2>

<?php if ($error): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?php echo $vendor['vendorName']; ?>" required>
    </div>
    <div class="form-group">
        <label for="location">Location</label>
        <input type="text" id="location" name="location" value="<?php echo $vendor['location']; ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="manage_vendors.php" class="btn btn-light">Cancel</a>
</form>

<?php include '../includes/footer.php'; ?>