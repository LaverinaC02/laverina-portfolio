<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$vendors = $conn->query("SELECT vendorID, vendorName FROM vendors");

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $productPrice = $_POST['productPrice'];
    $vendorID = $_POST['vendorID'];

    if (empty($name) || empty($description) || empty($productPrice) || empty($vendorID)) {
        $error = 'Please fill in all fields.';
    } 
    elseif (!is_numeric($productPrice) || $productPrice <= 0) {
        $error = 'Invalid price.';
    } 
    elseif (!isset($_FILES['image']) || $_FILES['image']['error'] != UPLOAD_ERR_OK) {
        $error = 'Please upload an image.';
    } 
    else {
        $file = $_FILES['image'];
        $allowed = ['jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            $error = 'Only JPG/PNG allowed.';
        } 
        elseif ($file['size'] > 2 * 1024 * 1024) {
            $error = 'File too large.';
        } 
        else {
        $stmt = $conn->prepare(
            "INSERT INTO products (productName, description, productPrice, vendorID, image)
            VALUES (?, ?, ?, ?, '')"
        );
        $stmt->bind_param("ssdi", $name, $description, $productPrice, $vendorID);
            if ($stmt->execute()) {
                $productID = $conn->insert_id;
                $newName = $productID . '_' . time() . '.' . $ext;
                $path = '../images/products/' . $newName;
                if (move_uploaded_file($file['tmp_name'], $path)) {
                    $stmt = $conn->prepare("UPDATE products SET image = ? WHERE productID = ?");
                    $stmt->bind_param("si", $newName, $productID);
                    $stmt->execute();
                    redirect('manage_products.php');
                } else {
                    $error = 'Upload failed.';
                    $conn->query("DELETE FROM products WHERE productID = $productID");
                }
                $stmt->close();
            } else {
                $error = 'Failed to add product.';
            }
        }
    }
}

include '../includes/header.php';
?>

<div class="card add-card">
<h2 class="text-white">Add New Product</h2>

<?php if ($error): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="" enctype="multipart/form-data">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea id="description" name="description" required></textarea>
    </div>
    <div class="form-group">
        <label for="productPrice">Price</label>
        <input type="number" id="productPrice" name="productPrice" step="0.01" required>
    </div>
    <div class="form-group">
        <label for="vendorID">Vendor</label>
        <select id="vendorID" name="vendorID" required>
            <?php while ($vendor = $vendors->fetch_assoc()): ?>
                <option value="<?php echo $vendor['vendorID']; ?>"><?php echo $vendor['vendorName']; ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="image">Image</label>
        <input type="file" id="image" name="image" accept=".jpg,.jpeg,.png" required>
    </div>
    <button type="submit" class="btn btn-primary btn-full">Add</button>
</form>
</div>

<?php include '../includes/footer.php'; ?>