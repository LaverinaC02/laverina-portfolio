<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$productID = $_GET['productID'] ?? 0;
if (!$productID) {
    redirect('manage_products.php');
}

$query = "SELECT * FROM products WHERE productID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $productID);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    redirect('manage_products.php');
}
$product = $result->fetch_assoc();
$stmt->close();

$vendors = $conn->query("SELECT vendorID, vendorName FROM vendors");

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $productPrice = $_POST['productPrice'];
    $vendorID = $_POST['vendorID'];

    if (empty($name) || empty($description) || empty($productPrice) || empty($vendorID)) {
        $error = 'Please fill in all fields.';
    } elseif (!is_numeric($productPrice) || $productPrice <= 0) {
        $error = 'Invalid price.';
    } else {
        $image = $product['image'];
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $file = $_FILES['image'];
            $allowed = ['jpg', 'jpeg', 'png'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) {
                $error = 'Only JPG/PNG allowed.';
            } elseif ($file['size'] > 2 * 1024 * 1024) {
                $error = 'File too large.';
            } else {
                $newName = $productID . '_' . time() . '.' . $ext;
                $path = '../images/products/' . $newName;
                if (move_uploaded_file($file['tmp_name'], $path)) {
                    if ($image && file_exists('../images/products/' . $image)) {
                        unlink('../images/products/' . $image);
                    }
                    $image = $newName;
                } else {
                    $error = 'Upload failed.';
                }
            }
        }
        if (!$error) {
            $stmt = $conn->prepare("UPDATE products SET productName = ?, description = ?, productPrice = ?, vendorID = ?, image = ? WHERE productID = ?");
            $stmt->bind_param("sdsisi", $name, $description, $productPrice, $vendorID, $image, $productID);
            if ($stmt->execute()) {
                redirect('manage_products.php');
            } else {
                $error = 'Failed to update product.';
            }
            $stmt->close();
        }
    }
}

include '../includes/header.php';
?>

<h2>Edit Product</h2>

<?php if ($error): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="" enctype="multipart/form-data">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?php echo $product['productName']; ?>" required>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <textarea id="description" name="description" required><?php echo $product['description']; ?></textarea>
    </div>
    <div class="form-group">
        <label for="price">Price</label>
        <input type="number" id="price" name="price" step="0.01" value="<?php echo $product['productPrice']; ?>" required>
    </div>
    <div class="form-group">
        <label for="vendorID">Vendor</label>
        <select id="vendorID" name="vendorID" required>
            <?php while ($vendor = $vendors->fetch_assoc()): ?>
                <option value="<?php echo $vendor['vendorID']; ?>" <?php if ($vendor['vendorID'] == $product['vendorID']) echo 'selected'; ?>><?php echo $vendor['vendorName']; ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="image">Image (leave empty to keep current)</label>
        <input type="file" id="image" name="image" accept=".jpg,.jpeg,.png">
        <p>Current image: <?php echo $product['image']; ?></p>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="manage_products.php" class="btn btn-light">Cancel</a>
</form>

<?php include '../includes/footer.php'; ?>