<?php
session_start();
include '../includes/db_connect.php';
include '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$userID = $_GET['userID'] ?? 0;
if (!$userID) {
    redirect('manage_users.php');
}

$query = "SELECT * FROM users WHERE userID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    redirect('manage_users.php');
}
$user = $result->fetch_assoc();
$stmt->close();

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $role = $_POST['role'];

    if (empty($username) || empty($email) || empty($gender) || empty($dob) || empty($role)) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email.';
    } elseif (!in_array($gender, ['Male', 'Female'])) {
        $error = 'Invalid gender.';
    } elseif (!in_array($role, ['member', 'admin'])) {
        $error = 'Invalid role.';
    } elseif (strtotime($dob) >= time()) {
        $error = 'Date of birth must be in the past.';
    } else {
        $stmt = $conn->prepare("SELECT userID FROM users WHERE (username = ? OR email = ?) AND userID != ?");
        $stmt->bind_param("ssi", $username, $email, $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $error = 'Username or email already taken.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, gender = ?, dob = ?, role = ? WHERE userID = ?");
            $stmt->bind_param("sssssi", $username, $email, $gender, $dob, $role, $userID);
            if ($stmt->execute()) {
                redirect('manage_users.php');
            } else {
                $error = 'Update failed.';
            }
            $stmt->close();
        }
    }
}

include '../includes/header.php';
?>

<h2>Edit User</h2>

<?php if ($error): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>

<form method="post" action="">
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" value="<?php echo $user['username']; ?>" required>
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>
    </div>
    <div class="form-group">
        <label>Gender</label>
        <label><input type="radio" name="gender" value="Male" <?php if ($user['gender'] == 'Male') echo 'checked'; ?> required> Male</label>
        <label><input type="radio" name="gender" value="Female" <?php if ($user['gender'] == 'Female') echo 'checked'; ?> required> Female</label>
    </div>
    <div class="form-group">
        <label for="dob">Date of Birth</label>
        <input type="date" id="dob" name="dob" value="<?php echo $user['dob']; ?>" required>
    </div>
    <div class="form-group">
        <label for="role">Role</label>
        <select id="role" name="role" required>
            <option value="member" <?php if ($user['role'] == 'member') echo 'selected'; ?>>Member</option>
            <option value="admin" <?php if ($user['role'] == 'admin') echo 'selected'; ?>>Admin</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="manage_users.php" class="btn btn-light">Cancel</a>
</form>

<?php include '../includes/footer.php'; ?>